export interface Show {
  id: number;
  title: string;
  overview: string;
  genre_ids: number[];
  popularity: number;
}
